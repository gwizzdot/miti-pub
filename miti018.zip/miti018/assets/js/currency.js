  // Shared exchange rates for both buy and sell
  const exchangeRates = {
    USD: 10,   // US Dollar
    ZIG: 4,    // ZiG
    EUR: 9,    // Euro
    GBP: 8.5,  // British Pound
    CNY: 1.2,  // Chinese Yuan
    XAF: 6     // Central African Franc
  };

  // ---------------- Buy Section ----------------
  const amountInput = document.getElementById('amount');
  const currencySelect = document.getElementById('currency');
  const receiveInput = document.getElementById('receive');
  const rateInfo = document.getElementById('rateInfo');

  function updateMitiCoins() {
    const currency = currencySelect.value;
    const rate = exchangeRates[currency];
    const amount = parseFloat(amountInput.value);

    rateInfo.innerText = `Exchange rate: 1 ${currency} = ${rate} MitiCoin`;

    if (!isNaN(amount) && amount > 0) {
      const miticoins = amount * rate;
      receiveInput.value = `${miticoins} MitiCoin`;
    } else {
      receiveInput.value = `0 MitiCoin`;
    }
  }

  if (currencySelect && amountInput) {
    currencySelect.addEventListener('change', updateMitiCoins);
    amountInput.addEventListener('input', updateMitiCoins);
  }

  // ---------------- Sell Section ----------------
  const sellAmountInput = document.getElementById('sellAmount');
  const sellCurrencySelect = document.getElementById('sellCurrency');
  const moneyReceivedInput = document.getElementById('moneyReceived');
  const sellRateInfo = document.getElementById('sellRateInfo');

  function updateSellValue() {
    const currency = sellCurrencySelect.value;
    const rate = exchangeRates[currency];
    const miticoins = parseFloat(sellAmountInput.value);

    sellRateInfo.innerText = `Exchange rate: 1 ${currency} = ${rate} MitiCoin`;

    if (!isNaN(miticoins) && miticoins > 0) {
      const money = miticoins / rate;
      moneyReceivedInput.value = `${money.toFixed(2)} ${currency}`;
    } else {
      moneyReceivedInput.value = `0.00`;
    }
  }

  if (sellCurrencySelect && sellAmountInput) {
    sellCurrencySelect.addEventListener('change', updateSellValue);
    sellAmountInput.addEventListener('input', updateSellValue);
  }