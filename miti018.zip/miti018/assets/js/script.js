// menu script

const menu = document.querySelector(".menu");
 const menuMain = menu.querySelector(".menu-main");
 const goBack = menu.querySelector(".go-back");
 const menuTrigger = document.querySelector(".mobile-menu-trigger");
 const closeMenu = menu.querySelector(".mobile-menu-close");
 let subMenu;
 menuMain.addEventListener("click", (e) =>{
 	if(!menu.classList.contains("active")){
 		return;
 	}
   if(e.target.closest(".menu-item-has-children")){
   	 const hasChildren = e.target.closest(".menu-item-has-children");
      showSubMenu(hasChildren);
   }
 });
 goBack.addEventListener("click",() =>{
 	 hideSubMenu();
 })
 menuTrigger.addEventListener("click",() =>{
 	 toggleMenu();
 })
 closeMenu.addEventListener("click",() =>{
 	 toggleMenu();
 })
 document.querySelector(".menu-overlay").addEventListener("click",() =>{
 	toggleMenu();
 })
 function toggleMenu(){
 	menu.classList.toggle("active");
 	document.querySelector(".menu-overlay").classList.toggle("active");
 }
 function showSubMenu(hasChildren){
    subMenu = hasChildren.querySelector(".sub-menu");
    subMenu.classList.add("active");
    subMenu.style.animation = "slideLeft 0.5s ease forwards";
    const menuTitle = hasChildren.querySelector("i").parentNode.childNodes[0].textContent;
    menu.querySelector(".current-menu-title").innerHTML=menuTitle;
    menu.querySelector(".mobile-menu-head").classList.add("active");
 }

 function  hideSubMenu(){  
    subMenu.style.animation = "slideRight 0.5s ease forwards";
    setTimeout(() =>{
       subMenu.classList.remove("active");	
    },300); 
    menu.querySelector(".current-menu-title").innerHTML="";
    menu.querySelector(".mobile-menu-head").classList.remove("active");
 }
 
 window.onresize = function(){
 	if(this.innerWidth >991){
 		if(menu.classList.contains("active")){
 			toggleMenu();
 		}

 	}
 }

// carousel script

function createSlider(carouselInnerId, carouselId) {
            let index = 0;
            let startX = 0;
            let endX = 0;
            let interval;
            let carouselInner = document.getElementById(carouselInnerId);
            let totalSlides = carouselInner.children.length;
            let dotsContainer = document.getElementById(`dots-${carouselInnerId}`);
            
            for (let i = 0; i < totalSlides; i++) {
                let dot = document.createElement("span");
                dot.classList.add("dot");
                dot.setAttribute("data-index", i);
                dot.addEventListener("click", function() {
                    index = parseInt(this.getAttribute("data-index"));
                    updateSlide();
                });
                dotsContainer.appendChild(dot);
            }

            function updateSlide() {
                carouselInner.style.transform = `translateX(-${index * 100}%)`;
                updateDots();
            }

            function updateDots() {
                document.querySelectorAll(`#dots-${carouselInnerId} .dot`).forEach((dot, i) => {
                    dot.classList.toggle("active", i === index);
                });
            }

            function nextSlide() {
                index = (index + 1) % totalSlides;
                updateSlide();
            }

            function prevSlide() {
                index = (index - 1 + totalSlides) % totalSlides;
                updateSlide();
            }

            function startSlider() {
                interval = setInterval(nextSlide, 7500);
            }

            function pauseSlider() {
                clearInterval(interval);
            }

            carouselInner.addEventListener("touchstart", (e) => startX = e.touches[0].clientX);
            carouselInner.addEventListener("touchmove", (e) => endX = e.touches[0].clientX);
            carouselInner.addEventListener("touchend", () => {
                if (startX - endX > 50) nextSlide();
                if (endX - startX > 50) prevSlide();
            });

            document.getElementById(carouselId).addEventListener("mouseover", pauseSlider);
            document.getElementById(carouselId).addEventListener("mouseout", startSlider);
            
            updateSlide();
            startSlider();
            window.nextSlide = nextSlide;
            window.prevSlide = prevSlide;
        }
        
        createSlider('carouselInner', 'wp-carousel');

