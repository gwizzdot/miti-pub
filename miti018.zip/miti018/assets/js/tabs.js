// tabs

function activateTabFromHash() {
  const hash = window.location.hash;
  if (hash === '#buy' || hash === '#sell') {
    const tabRadio = document.getElementById(hash.substring(1));
    if (tabRadio) {
      tabRadio.checked = true;
    }
  }
}

activateTabFromHash();

document.querySelectorAll('.tabs > input[type=radio]').forEach(input => {
  input.addEventListener('change', () => {
    if (input.checked) {
      history.pushState(null, '', `#${input.id}`);
      // Removed scrollToTabContent to disable auto scroll
    }
  });
});

window.addEventListener('popstate', activateTabFromHash);
