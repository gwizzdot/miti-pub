// banner script
document.addEventListener("DOMContentLoaded", function() {
  const links = document.querySelectorAll(".link");
  const image = document.getElementById("hover-image");
  const defaultImage = "assets/img/default.png"; // Image to revert to

  links.forEach(link => {
    // On hover, change the image temporarily
    link.addEventListener("mouseover", function() {
      const imgName = "assets/img/" + this.getAttribute("data-image") + ".png";
      image.src = imgName;
    });

    // Prevent default click behavior (optional)
    link.addEventListener("click", function(event) {
      // event.preventDefault(); // disabled to allow link clicks
    });

    // On hover out of each card, revert to default image
    link.addEventListener("mouseleave", function() {
      image.src = defaultImage;
    });
  });
});