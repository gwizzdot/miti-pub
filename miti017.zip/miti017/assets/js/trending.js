// trending script

        function scrollTrending() {
            let firstItem = $(".trending-feed .trending-item:first");
            firstItem.animate({ marginTop: "-30px", opacity: 0 }, 500, function () {
                $(this).appendTo(".trending-feed").css({ marginTop: "0", opacity: 1 });
            });
        }

        // Auto-scroll every 4 seconds
        let trendingInterval = setInterval(scrollTrending, 4000);

        // Pause on hover
        $(".trending-panel").hover(
            function () {
                clearInterval(trendingInterval);
            },
            function () {
                trendingInterval = setInterval(scrollTrending, 4000);
            }
        );

        // Manual scroll on button click
        $(".next-trending-item").click(function () {
            scrollTrending();
        });