  const trees = [
    { name: "Pine", price: 65.35, change: -4.96 },
    { name: "Baobab", price: 27.19, change: 9.86 },
    { name: "Acacia", price: 31.98, change: -1.35 },
    { name: "Lantana", price: 72.31, change: 6.59 },
    { name: "Aloe Vera", price: 57.54, change: -9.31 },
    { name: "Mahogany", price: 41.06, change: 8.23 },
    { name: "Mango", price: 47.96, change: -2.81 },
    { name: "Guava", price: 18.88, change: -8.77 },
    { name: "Cypress", price: 56.71, change: -4.45 },
    { name: "Eucalyptus", price: 13.62, change: 3.58 },
    { name: "Teak", price: 49.04, change: -2.3 },
    { name: "Neem", price: 70.63, change: -3.02 },
    { name: "Jacaranda", price: 66.86, change: -2.5 },
    { name: "Mulberry", price: 36.97, change: -0.21 },
    { name: "Avocado", price: 17.15, change: 0.03 },
    { name: "Bamboo", price: 5.79, change: 5.06 },
    { name: "Marula", price: 47.94, change: -4.61 },
    { name: "Palm", price: 83.78, change: -3.38 },
    { name: "Cedar", price: 88.66, change: -0.94 },
    { name: "Fig", price: 83.13, change: -5.87 }
  ];

  const container = document.getElementById("treeTicker");
  const allTrees = [...trees, ...trees]; // Duplicate for loop scroll

  allTrees.forEach(tree => {
    const treeSlug = tree.name.toLowerCase().replace(/\s+/g, '-');
    const imgPath = `/assets/img/${treeSlug}.png`;

    const link = document.createElement("a");
    link.href = `#${treeSlug}`;
    link.className = "tree-item";

    link.innerHTML = `
      <div class="tree-icon">
        <img src="${imgPath}" alt="${tree.name}">
      </div>
      <div class="tree-details">
        <span class="tree-name">${tree.name}</span>
        <span class="tree-price">$${tree.price.toFixed(2)}</span>
        <span class="tree-change ${tree.change < 0 ? 'down' : 'up'}">
          ${tree.change > 0 ? '+' : ''}${tree.change}%
        </span>
      </div>
    `;

    container.appendChild(link);
  });